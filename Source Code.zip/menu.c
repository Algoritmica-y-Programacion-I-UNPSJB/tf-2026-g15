#include <stdio.h>
#include <conio.h>
#include "Library/menu.h"
#include "Library/player.h"
#include "Library/games.h"

static int option = 0;
static int keyword = 0;

static int mostrar_menu(void){
    option = 0;
    keyword = 0;

    while(keyword != 13){

        printf("%s Jugar\n", option == 0 ? ">" : " ");
        printf("%s Guardar juego\n", option == 1 ? ">" : " ");
        printf("%s Cargar juego\n", option == 2 ? ">" : " ");
        printf("%s Salir\n", option == 3 ? ">" : " ");

        keyword = _getch();

        if(keyword == 224){
            printf("\033[4A\r");
            keyword = _getch();

            //tecla arriba
            if(keyword == 72)
                option--;
            //tecla abajo
            if(keyword == 80)
                option ++;
            
        }

        //limites de las opciones
        if(option < 0)
            option = 3;

        if(option > 3)
            option = 0;

    }

    return option;
}

static void mostrar_juegos(Player *player){
    option = 0;
    keyword = 0;

    printf("\nDinero actuales: %llu\n", player->wallet);
    printf("Elija el juego:\n");

    while(keyword != 13){
        printf("%s Ruleta\n", option == 0 ? ">" : " ");
        printf("%s Volver\n", option == 1 ? ">" : " ");
        printf("Work in progress\n");

        keyword = _getch();

        if(keyword == 224){
            printf("\033[3A\r");
            keyword = _getch();

            //tecla arriba
            if(keyword == 72)
                option--;
            //tecla abajo
            if(keyword == 80)
                option ++;
            
        }

        //limites de las opciones
        if(option < 0)
            option = 1;

        if(option > 1)
            option = 0;
    }

    printf("\n");

    switch(option){
        case 0:
            roulette(player);
            return;

        case 1:
            return;
    }
}

int menu(Player *player){
    printf("====== CASINO ======\n");
    printf("Bienvenido %s\n", player->name);

    while(1){
        switch(mostrar_menu()){
            case 0:  //Jugar
                mostrar_juegos(player);
                return 0;

            case 1:
                save_game(player, 1);
                return 0;

            case 2:
                if(load_game(player) == 1){
                    return 1;
                }
                return 0;

            case 3:  //Salir
                save_game(player, 1);
                printf("See you next time :)");
                return 1;
        }
    }
}