#include <stdio.h>
#include "../Library/player.h"
#include "../Library/games.h"
#include "roulette.h"
#include "setbet.h"
#include "start_bet.h"

static void show_roulette(){

    printf("______________________________________________\n");
    printf("|  |3 6 9 12 15 18 21 24 27 30 33 36 |2:1 3ro|\n");
    printf("|0 |2 5 8 11 14 17 20 23 26 29 32 35 |2:1 2do|\n");
    printf("|  |1 4 7 10 13 16 19 22 25 28 31 34 |2:1 1ro|\n");
    printf("|==|========|===========|============|=======|\n");
    printf("   |1er 12na| 2da 12na  | 3ra 12na   |-------|\n");
    printf("   |1-18 | PAR | NEGRO | ROJO | IMPAR | 19-36|\n");
    printf("   |=========================================|\n");

    return;
}

static void init_bet(int *user, Player *player, Bet *bet, int *amount_bet, int *count){
    if(*user == 9 || *user == 10)
        return;
    
    int monto = 0;

    printf("Saldo: %llu$\n", player->wallet);
    printf("Cuanto desea apostar?\n>");
    scanf("%d", &monto);

    if(monto < 1){
        printf("No\n");
        return;
    }

    if((monto + bet->total) <= player->wallet){
        switch(*user){
            case 1:
                bet_number(user, player, bet, amount_bet, &monto, count);
            break;
        
            case 2: //Even
                bet_even(user, player, bet, amount_bet, &monto);
            break;

            case 3: //Odd
                bet_odd(user, player, bet, amount_bet, &monto);
            break;

            case 4: //12nas
                bet_dozens(user, player, bet, amount_bet, &monto);
            break;

            case 5: //columnas
                bet_columns(user, player, bet, amount_bet, &monto);
            break;

            case 6: //color
                bet_color(user, player, bet, amount_bet, &monto);
            break;

            case 7: //1-18
                bet_onetoeighteen(user, player, bet, amount_bet, &monto);
            break;

            case 8: //19-36
                bet_nineteentothirtysix(user, player, bet, amount_bet, &monto);
            break;

            default:
                printf("Opcion invalida\n");
                return;
        }
        
    }else{
        printf("Saldo insuficiente :(\n");
    }

    *user = 0;
    return;
}

void roulette(Player *player){
    Bet bet;

    int user = 0, amount_bet = 0, count = 0;

    printf("======= Ruleta ======\n");
    
    do{
        show_roulette();
    
        bettozero(&bet, &count, &amount_bet);

        printf("\nhaga su apuesta: \n");
        do{
            printf("1. Numero especifico\n");
            printf("2. Par\n");
            printf("3. Impar\n");
            printf("4. 12-nas\n");
            printf("5. Columnas\n");
            printf("6. color\n");
            printf("7. 1-18\n");
            printf("8. 19-36\n");
            printf("9. iniciar\n");
            printf("10. Salir\n>");
            scanf("%d", &user);

            init_bet(&user, player, &bet, &amount_bet, &count);

            if(user == 9 && amount_bet == 0){
                printf("No puede jugar si no hace una apuesta\n");
                user = 0;
            }

            printf("total apostado: %d$\n\n", bet.total);
        }while(user != 9 && user != 10);

        if(user == 9){
            player->wallet -= bet.total;
            start_bet(player, &bet, count);
        }

        printf("Saldo: %llu$\n", player->wallet);
        bettozero(&bet, &count, &amount_bet);
        save_game(player, 0);
        printf("=================================================================\n");
    }while(user != 10);

    printf("Bye Bye\n\n");
    return;
}